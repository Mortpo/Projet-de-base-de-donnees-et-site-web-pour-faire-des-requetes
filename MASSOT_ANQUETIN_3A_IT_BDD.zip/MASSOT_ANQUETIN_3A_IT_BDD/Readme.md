Commande a executer une fois dans mariadb et apres avoir lancer mariadb dans le dossier ou ce situe le projet :

SOURCE mysql.sql;
